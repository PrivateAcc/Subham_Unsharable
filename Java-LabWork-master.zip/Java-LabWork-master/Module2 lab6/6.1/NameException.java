package labAssignments;

public class NameException extends Exception
{

	public NameException(String str)
	{
		super();
		System.out.println(str);
	}
	
}
