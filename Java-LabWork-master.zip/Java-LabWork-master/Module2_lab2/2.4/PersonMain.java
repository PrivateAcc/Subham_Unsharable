package java_project1;


public class PersonMain {
	public static void main(String[] args) {
		Person person = new Person();
			person.setPhoneNumber(9547909577L);
			person.showDetails();
			person.showPhoneNumber();
			
		}

}
