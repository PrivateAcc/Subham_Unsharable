package java_project1;


public class Person {

	private String firstName;
	private String lastName;
	private char gender;
	private long phoneNumber;
	
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public Person() {
		this("Subham","Agarwal",'M');
		System.out.println("Showing Person's Details from calling parameterized Constructor through Default Constructor\n");
		
	}
	
	public Person(String fn,String ln,char gndr)
	{
		setFirstName(fn);
		setLastName(ln);
		setGender(gndr);
		
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	void showPhoneNumber(){
		System.out.println("PhoneNumber is: "+getPhoneNumber());
	}
	
	public void showDetails() {
		System.out.println("Person Details");
		System.out.println("______________");
		System.out.println();
		System.out.println("First Name:"+getFirstName());
		System.out.println("Last Name: "+getLastName());
		System.out.println("Gender: "+getGender());
	
	}
	
}
