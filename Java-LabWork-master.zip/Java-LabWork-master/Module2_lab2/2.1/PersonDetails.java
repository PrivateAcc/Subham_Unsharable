package java_project1;

public class PersonDetails{
	public static void main(String[] args) {
		System.out.println("Person Details");
		System.out.println("______________");
		System.out.println();
		System.out.println("First Name:"+args[0]);
		System.out.println("Last Name: "+args[1]);
		System.out.println("Gender: "+args[2]);
		System.out.println("Age: "+args[3]);
		
	}

}
