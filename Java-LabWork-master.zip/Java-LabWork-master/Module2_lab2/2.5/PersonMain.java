package java_project1;

//import java_project1.Person.Gender;

public class PersonMain {
	public static void main(String[] args) {
		Person person = new Person();
			person.setPhoneNumber(9547909577l);
			person.showDetails();
			person.showPhoneNumber();
			
		}

}
