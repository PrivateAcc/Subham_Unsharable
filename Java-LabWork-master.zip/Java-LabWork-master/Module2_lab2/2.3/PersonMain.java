package java_project1;


public class PersonMain {
	public static void main(String[] args) {
		Person person = new Person();
			//person.setPhoneNumber(954790957);
			person.showDetails();
			//person.showPhoneNumber();
			
		}

}
