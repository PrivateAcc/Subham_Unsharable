package exception;

public class TicketException extends Exception {

	public TicketException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
