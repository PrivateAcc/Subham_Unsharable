# Oracle-WebBasics
This File contains all the Labwork of Module1 (SQL+PL/SQL+HTML/XML/JAVASCRIPT)
